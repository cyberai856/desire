"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import SchoolLogo from "@/components/SchoolLogo";

type Role = "student" | "admin";
type Tab = "ballot" | "results" | "candidates" | "guide" | "settings";
type Candidate = {
  id: number;
  position: string;
  name: string;
  className: string;
  tagline: string;
  manifesto: string;
  accent: string;
  initials: string;
  imageUrl?: string | null;
};
type Settings = {
  startAt: string;
  endAt: string;
  administrationEmail: string;
  notificationSent: boolean;
  notificationSentAt?: string | null;
};
type ElectionData = {
  settings: Settings;
  candidates: Candidate[];
  totals: Record<string, number>;
  positions: string[];
  mail?: { sent: boolean; reason: string };
};
type Session = { role: Role; identity: string; token?: string };
type Notify = (type: "success" | "error" | "info", message: string) => void;

const CAMPUS_SLIDES = [
  { src: "/school-group.webp", label: "School community assembly" },
  { src: "/school-building.webp", label: "Main academic block" },
  { src: "/school-courtyard.webp", label: "School courtyard" },
  { src: "/school-classroom.webp", label: "Students in class" },
  { src: "/rosmini-campus.webp", label: "Rosmini campus" },
];

const ACCENTS = [
  "#1b3f94",
  "#c8102e",
  "#d9a441",
  "#2f7d4f",
  "#7c3aed",
  "#0f766e",
  "#be123c",
  "#b45309",
  "#4f46e5",
  "#0369a1",
  "#15803d",
  "#c2417a",
];

function readStoredSession(): Session | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem("rosmini-session") ?? window.sessionStorage.getItem("rosmini-session");
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Session;
    if (!parsed || (parsed.role !== "student" && parsed.role !== "admin") || typeof parsed.identity !== "string") return null;
    return parsed;
  } catch {
    return null;
  }
}

function readLastStudent(): string | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem("rosmini-last-student");
    return raw && /^\d{3}$/.test(raw) ? raw : null;
  } catch {
    return null;
  }
}

function writeSession(session: Session) {
  try {
    const raw = JSON.stringify(session);
    window.localStorage.setItem("rosmini-session", raw);
    window.sessionStorage.setItem("rosmini-session", raw);
  } catch {
    /* storage unavailable */
  }
}

function clearSession() {
  try {
    window.localStorage.removeItem("rosmini-session");
    window.sessionStorage.removeItem("rosmini-session");
  } catch {
    /* storage unavailable */
  }
}

function Icon({ name, size = 18 }: { name: string; size?: number }) {
  const common = { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.8, strokeLinecap: "round" as const, strokeLinejoin: "round" as const, "aria-hidden": true };
  const paths: Record<string, React.ReactNode> = {
    arrow: <><path d="M5 12h14" /><path d="m13 6 6 6-6 6" /></>,
    shield: <><path d="M12 3 20 6v5c0 5-3.4 8.5-8 10-4.6-1.5-8-5-8-10V6l8-3Z" /><path d="m9 12 2 2 4-4" /></>,
    clock: <><circle cx="12" cy="12" r="8.5" /><path d="M12 7v5l3.2 2" /></>,
    chart: <><path d="M4 19V5" /><path d="M4 19h16" /><path d="m7 15 3-4 3 2 5-7" /></>,
    users: <><path d="M16 20v-1.4a3.6 3.6 0 0 0-3.6-3.6H7.6A3.6 3.6 0 0 0 4 18.6V20" /><circle cx="10" cy="7.5" r="3.5" /><path d="M16 4.5a3.5 3.5 0 0 1 0 6.8M20 20v-1.3a3.6 3.6 0 0 0-2.4-3.4" /></>,
    check: <><path d="m5 12 4 4L19 6" /></>,
    logout: <><path d="M10 17l5-5-5-5" /><path d="M15 12H3" /><path d="M21 19V5a2 2 0 0 0-2-2h-5" /></>,
    settings: <><path d="M12 15.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z" /><path d="m19.4 15 .1.1a1.8 1.8 0 0 1-2.5 2.5l-.1-.1a1.8 1.8 0 0 0-3 1.3v.2a1.8 1.8 0 0 1-3.6 0v-.2a1.8 1.8 0 0 0-3-1.3l-.1.1a1.8 1.8 0 0 1-2.5-2.5l.1-.1a1.8 1.8 0 0 0-1.3-3H3.3a1.8 1.8 0 0 1 0-3.6h.2a1.8 1.8 0 0 0 1.3-3l-.1-.1a1.8 1.8 0 0 1 2.5-2.5l.1.1a1.8 1.8 0 0 0 3-1.3v-.2a1.8 1.8 0 0 1 3.6 0v.2a1.8 1.8 0 0 0 3 1.3l.1-.1a1.8 1.8 0 0 1 2.5 2.5l-.1.1a1.8 1.8 0 0 0 1.3 3h.2a1.8 1.8 0 0 1 0 3.6h-.2a1.8 1.8 0 0 0-1.3 3Z" /></>,
    info: <><circle cx="12" cy="12" r="8.5" /><path d="M12 10.8v5" /><path d="M12 7.7h.01" /></>,
    mail: <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="m3 7 9 6 9-6" /></>,
    google: <><path d="M21 12.2c0-5-3.9-8.6-8.8-8.6A8.8 8.8 0 1 0 20.8 15h-8.6v-3h5.1a5.3 5.3 0 1 1-5.1-5.4c1.4 0 2.7.5 3.7 1.4l2.1-2.1" /></>,
    lock: <><rect x="5" y="10" width="14" height="11" rx="2" /><path d="M8 10V7a4 4 0 0 1 8 0v3" /></>,
    menu: <><path d="M4 7h16M4 12h16M4 17h16" /></>,
    close: <><path d="m6 6 12 12M18 6 6 18" /></>,
    spark: <><path d="m12 3 1.3 5.7L19 10l-5.7 1.3L12 17l-1.3-5.7L5 10l5.7-1.3L12 3Z" /><path d="m19 16 .5 2.5L22 19l-2.5.5L19 22l-.5-2.5L16 19l2.5-.5L19 16Z" /></>,
    trash: <><path d="M4 7h16" /><path d="M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" /><path d="M6 7l1 13a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1l1-13" /><path d="M10 11v6M14 11v6" /></>,
  };
  return <svg {...common}>{paths[name] ?? paths.info}</svg>;
}

function formatTimeLeft(milliseconds: number) {
  if (milliseconds <= 0) return "00d 00h 00m 00s";
  const totalSeconds = Math.floor(milliseconds / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return `${String(days).padStart(2, "0")}d ${String(hours).padStart(2, "0")}h ${String(minutes).padStart(2, "0")}m ${String(seconds).padStart(2, "0")}s`;
}

function dateTimeInput(value: string) {
  const date = new Date(value);
  const offset = date.getTimezoneOffset();
  return new Date(date.getTime() - offset * 60 * 1000).toISOString().slice(0, 16);
}

function prettyDate(value: string) {
  return new Intl.DateTimeFormat("en-TZ", { day: "numeric", month: "short", year: "numeric", hour: "numeric", minute: "2-digit" }).format(new Date(value));
}

function statusFor(settings?: Settings) {
  if (!settings) return "loading";
  const now = Date.now();
  if (now < new Date(settings.startAt).getTime()) return "upcoming";
  if (now >= new Date(settings.endAt).getTime()) return "closed";
  return "active";
}

function CampusSlideshow() {
  const [index, setIndex] = useState(0);
  useEffect(() => {
    const timer = window.setInterval(() => setIndex((current) => (current + 1) % CAMPUS_SLIDES.length), 4600);
    return () => window.clearInterval(timer);
  }, []);
  useEffect(() => {
    [1, 2].forEach((offset) => {
      const pre = new Image();
      pre.src = CAMPUS_SLIDES[(index + offset) % CAMPUS_SLIDES.length].src;
    });
  }, [index]);
  const activeSlide = CAMPUS_SLIDES[index];
  return (
    <>
      <img key={activeSlide.src} className="slide" src={activeSlide.src} alt={activeSlide.label} />
      <div className="slide-dots">
        {CAMPUS_SLIDES.map((slide, slideIndex) => (
          <button key={slide.src} className={slideIndex === index ? "active" : ""} onClick={() => setIndex(slideIndex)} aria-label={`Show photo: ${slide.label}`} />
        ))}
      </div>
    </>
  );
}

function DataLoading() {
  return (
    <div className="data-loading" role="status">
      <SchoolLogo size={44} />
      <p>Connecting to the election room…</p>
      <div className="loading-bar"><span /></div>
    </div>
  );
}

function WelcomeModal({ close }: { close: () => void }) {
  return (
    <div className="modal-backdrop">
      <section className="welcome-modal" role="dialog" aria-modal="true" aria-labelledby="welcome-title">
        <SchoolLogo size={72} />
        <p className="eyebrow">Rosmini Secondary School · Tanga</p>
        <h2 id="welcome-title">Habari ndugu!</h2>
        <p className="welcome-lead">Karibu katika mfumo wa upiga kura wa Rosmini. <em>Welcome to the Rosmini student leadership voting system.</em></p>
        <ul className="welcome-points">
          <li><Icon name="users" size={15} /><span>Kuingia ni rahisi: tumia <strong>namba yako ya msingi (001 – 560)</strong> — hakuna password. <em>Sign in with your student number, no password needed.</em></span></li>
          <li><Icon name="check" size={15} /><span>Upige kura <strong>moja kwa kila nafasi</strong>: Head Boy, Head Girl, na wanafunzi wengine. <em>One vote per position — Head Boy, Head Girl, and other prefects.</em></span></li>
          <li><Icon name="shield" size={15} /><span>Kagua uchaguzi wako kwanza, kisha <strong>thibitisha</strong> kabla ya kutuma. <em>Review your ballot, then confirm before it is submitted.</em></span></li>
          <li><Icon name="clock" size={15} /><span>Kura zinapatikana <strong>kipindi cha rasmi</strong> tu — fuata countdown. <em>Voting is open only inside the official window — watch the countdown.</em></span></li>
        </ul>
        <button className="primary-button welcome-button" onClick={close}>Endelea · Continue <Icon name="arrow" size={16} /></button>
        <p className="welcome-motto">Love to be the Law · Tanga, Tanzania</p>
      </section>
    </div>
  );
}

export default function HomePage() {
  const [session, setSession] = useState<Session | null>(null);
  const [loginMode, setLoginMode] = useState<Role>("student");
  const [studentId, setStudentId] = useState(() => readLastStudent() ?? "001");
  const [adminUsername, setAdminUsername] = useState("admin");
  const [adminPassword, setAdminPassword] = useState("");
  const [data, setData] = useState<ElectionData | null>(null);
  const [loginError, setLoginError] = useState("");
  const [toast, setToast] = useState<{ type: "success" | "error" | "info"; message: string } | null>(null);
  const [tab, setTab] = useState<Tab>("ballot");
  const [mobileMenu, setMobileMenu] = useState(false);
  const [selections, setSelections] = useState<Record<string, number>>({});
  const [submittedPositions, setSubmittedPositions] = useState<string[]>([]);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [manifesto, setManifesto] = useState<Candidate | null>(null);
  const [remaining, setRemaining] = useState(0);
  const [schedule, setSchedule] = useState({ startAt: "", endAt: "", administrationEmail: "" });
  const [savingSchedule, setSavingSchedule] = useState(false);
  const [sendingNotice, setSendingNotice] = useState(false);
  const [lastStudent, setLastStudent] = useState<string | null>(null);
  const [welcomeOpen, setWelcomeOpen] = useState(false);

  const notify = useCallback<Notify>((type, message) => setToast({ type, message }), []);

  const dismissWelcome = useCallback(() => {
    try {
      window.sessionStorage.setItem("rosmini-welcome-v1", "1");
    } catch {
      /* storage unavailable */
    }
    setWelcomeOpen(false);
  }, []);

  useEffect(() => {
    try {
      if (!window.sessionStorage.getItem("rosmini-welcome-v1")) setWelcomeOpen(true);
    } catch {
      setWelcomeOpen(true);
    }
  }, []);

  const fetchElection = useCallback(async () => {
    try {
      const response = await fetch("/api/election", { cache: "no-store" });
      if (!response.ok) throw new Error("Election data is unavailable right now.");
      const nextData = await response.json() as ElectionData;
      setData(nextData);
      setSchedule({ startAt: dateTimeInput(nextData.settings.startAt), endAt: dateTimeInput(nextData.settings.endAt), administrationEmail: nextData.settings.administrationEmail });
      setRemaining(Math.max(0, new Date(nextData.settings.endAt).getTime() - Date.now()));
    } catch (error) {
      setToast({ type: "error", message: error instanceof Error ? error.message : "Could not load the election." });
    }
  }, []);

  useEffect(() => {
    const stored = readStoredSession();
    const valid = stored && !(stored.role === "admin" && !stored.token) ? stored : null;
    if (valid) {
      setSession(valid);
      if (valid.role === "admin") setTab("results");
    }
    const remembered = readLastStudent();
    if (remembered) setLastStudent(remembered);
    void fetchElection();
  }, [fetchElection]);

  useEffect(() => {
    const refresh = window.setInterval(() => {
      void fetchElection();
    }, 30000);
    return () => window.clearInterval(refresh);
  }, [fetchElection]);

  useEffect(() => {
    if (!data) return;
    const tick = window.setInterval(() => {
      setRemaining(Math.max(0, new Date(data.settings.endAt).getTime() - Date.now()));
    }, 1000);
    return () => window.clearInterval(tick);
  }, [data]);

  useEffect(() => {
    if (!session || session.role !== "student") return;
    fetch(`/api/votes?studentId=${session.identity}`, { cache: "no-store" })
      .then((response) => response.json())
      .then((body: { votes?: Array<{ position: string; candidateId: number }> }) => {
        const submitted = body.votes ?? [];
        setSubmittedPositions(submitted.map((vote) => vote.position));
        setSelections((current) => {
          const next = { ...current };
          submitted.forEach((vote) => { next[vote.position] = vote.candidateId; });
          return next;
        });
      })
      .catch(() => undefined);
  }, [session]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 4200);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const status = statusFor(data?.settings);
  const totalVotes = useMemo(() => Object.values(data?.totals ?? {}).reduce((sum, value) => sum + value, 0), [data]);
  const selectedCount = Object.keys(selections).filter((position) => !submittedPositions.includes(position)).length;

  async function logIn(role: Role, identity: string, password = "") {
    const cleanIdentity = identity.trim().toLowerCase();
    if (role === "student") {
      if (!/^\d{3}$/.test(cleanIdentity) || Number(cleanIdentity) < 1 || Number(cleanIdentity) > 560) {
        setLoginError("Use a student number from 001 through 560.");
        return;
      }
    } else if (!cleanIdentity || !password) {
      setLoginError("Enter both the administrator username and password.");
      return;
    }
    let adminToken: string | undefined;
    if (role === "admin") {
      try {
        const response = await fetch("/api/auth", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username: cleanIdentity, password }) });
        if (!response.ok) {
          const body = await response.json().catch(() => null) as { error?: string } | null;
          setLoginError(body?.error ?? "Administrator authentication failed.");
          return;
        }
        const body = await response.json() as { token?: string };
        adminToken = body.token;
      } catch {
        setLoginError("The administration server could not be reached. Please try again.");
        return;
      }
    }
    const next = { role, identity: role === "student" ? cleanIdentity.padStart(3, "0") : cleanIdentity, token: adminToken } as Session;
    writeSession(next);
    setSession(next);
    setLoginError("");
    setTab(role === "admin" ? "results" : "ballot");
    if (role === "student") {
      try {
        window.localStorage.setItem("rosmini-last-student", next.identity);
      } catch {
        /* storage unavailable */
      }
      setLastStudent(next.identity);
    }
    setToast({ type: "success", message: role === "student" ? `Welcome, student ${next.identity}.` : "Administrator access verified." });
  }

  function logOut() {
    if (session?.role === "student") {
      try {
        window.localStorage.setItem("rosmini-last-student", session.identity);
      } catch {
        /* storage unavailable */
      }
    }
    clearSession();
    setSession(null);
    setSelections({});
    setSubmittedPositions([]);
    setMobileMenu(false);
  }

  function chooseCandidate(position: string, candidateId: number) {
    if (status !== "active" || submittedPositions.includes(position)) return;
    setSelections((current) => ({ ...current, [position]: candidateId }));
  }

  async function submitBallot() {
    if (!session || session.role !== "student") return;
    const newSelections = Object.entries(selections)
      .filter(([position]) => !submittedPositions.includes(position))
      .map(([position, candidateId]) => ({ position, candidateId }));
    if (!newSelections.length) {
      notify("info", "Choose at least one position before reviewing your ballot.");
      return;
    }
    try {
      const response = await fetch("/api/votes", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ studentId: session.identity, selections: newSelections }) });
      const body = await response.json() as { error?: string; count?: number };
      if (!response.ok) throw new Error(body.error ?? "Your ballot could not be saved.");
      setSubmittedPositions((current) => [...current, ...newSelections.map((selection) => selection.position)]);
      setReviewOpen(false);
      notify("success", `${body.count ?? newSelections.length} choice${(body.count ?? 1) === 1 ? "" : "s"} recorded securely.`);
      await fetchElection();
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "Your ballot could not be saved.");
    }
  }

  async function saveSchedule(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!session || session.role !== "admin") return;
    setSavingSchedule(true);
    try {
      const response = await fetch("/api/election", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token: session.token, startAt: schedule.startAt, endAt: schedule.endAt, administrationEmail: schedule.administrationEmail }) });
      const body = await response.json() as { error?: string };
      if (!response.ok) throw new Error(body.error ?? "Could not save the schedule.");
      notify("success", "Election schedule saved. The countdown is live for students.");
      await fetchElection();
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "Could not save the schedule.");
    } finally {
      setSavingSchedule(false);
    }
  }

  async function closeElection() {
    if (!session || session.role !== "admin") return;
    setSendingNotice(true);
    try {
      const response = await fetch("/api/election", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token: session.token }) });
      const body = await response.json() as { error?: string };
      if (!response.ok) throw new Error(body.error ?? "The closure notice could not be sent.");
      notify("success", "Final results emailed to school administration.");
      await fetchElection();
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "The closure notice could not be sent.");
    } finally {
      setSendingNotice(false);
    }
  }

  if (!session) {
    return (
      <main className="login-page">
        <section className="campus-hero" aria-label="Rosmini Secondary School Tanga welcome">
          <CampusSlideshow />
          <div className="hero-wash" />
          <div className="hero-content">
            <div className="hero-brand">
              <SchoolLogo size={80} />
              <div className="brand-copy light">
                <strong>ROSMINI</strong>
                <span>SECONDARY SCHOOL · TANGA</span>
              </div>
            </div>
            <div className="hero-copy">
              <p className="eyebrow light-eyebrow">Love to be the law</p>
              <h1>Choose the<br /><em>leaders</em> who<br />move us forward.</h1>
              <p className="hero-description">A considered voice. A shared future. Welcome to the Rosmini Secondary School student leadership election portal.</p>
            </div>
            <div className="hero-footer"><span>LOVE TO BE THE LAW</span><span className="footer-line" /><span>TANGA · TANZANIA</span></div>
          </div>
        </section>
        <section className="login-stage">
          <div className="login-orb orb-one" /><div className="login-orb orb-two" />
          <div className="login-card">
            <div className="login-brand"><SchoolLogo size={64} /><div className="brand-copy center"><strong>ROSMINI</strong><span>SECONDARY SCHOOL · TANGA</span></div></div>
            <div className="login-heading"><p className="eyebrow">Student leadership 2025/26</p><h2>Step into your voice.</h2><p>Sign in to cast your vote for the prefect team.</p></div>
            {loginMode === "student" && lastStudent && (
              <div className="welcome-back">
                <div><strong>Welcome back, Student {lastStudent}</strong><span>Continue where you left off</span></div>
                <button onClick={() => void logIn("student", lastStudent)}>Continue <Icon name="arrow" size={13} /></button>
              </div>
            )}
            <div className="mode-switch" role="tablist" aria-label="Login type">
              <button className={loginMode === "student" ? "active" : ""} onClick={() => { setLoginMode("student"); setLoginError(""); }} role="tab" aria-selected={loginMode === "student"}><Icon name="users" size={16} /> Student</button>
              <button className={loginMode === "admin" ? "active" : ""} onClick={() => { setLoginMode("admin"); setLoginError(""); }} role="tab" aria-selected={loginMode === "admin"}><Icon name="shield" size={16} /> Administration</button>
            </div>
            {loginMode === "student" ? (
              <form onSubmit={(event) => { event.preventDefault(); void logIn("student", studentId); }}>
                <label className="field-label" htmlFor="student-id">Student number</label>
                <div className="input-wrap"><span className="input-prefix">RS</span><input id="student-id" value={studentId} onChange={(event) => setStudentId(event.target.value.replace(/\D/g, "").slice(0, 3))} inputMode="numeric" placeholder="001" autoComplete="off" /><span className="input-hint">001 — 560</span></div>
                <p className="field-note"><Icon name="lock" size={14} /> Passwordless access · your number is your identity</p>
                <button className="primary-button login-button" type="submit">Enter the ballot <Icon name="arrow" size={17} /></button>
              </form>
            ) : (
              <form onSubmit={(event) => { event.preventDefault(); void logIn("admin", adminUsername, adminPassword); }}>
                <label className="field-label" htmlFor="admin-username">Administrator username</label>
                <div className="input-wrap"><span className="input-icon"><Icon name="users" size={17} /></span><input id="admin-username" value={adminUsername} onChange={(event) => setAdminUsername(event.target.value)} placeholder="admin" autoComplete="username" /></div>
                <div className="field-gap">
                  <label className="field-label" htmlFor="admin-password">Password</label>
                  <div className="input-wrap"><span className="input-icon"><Icon name="lock" size={16} /></span><input id="admin-password" type="password" value={adminPassword} onChange={(event) => setAdminPassword(event.target.value)} placeholder="••••••••••••" autoComplete="current-password" /></div>
                </div>
                <p className="field-note"><Icon name="shield" size={14} /> Restricted access · verified privately by the server</p>
                <button className="primary-button login-button" type="submit">Enter the console <Icon name="arrow" size={17} /></button>
              </form>
            )}
            {loginError && <div className="form-error"><Icon name="info" size={15} /> {loginError}</div>}
            <p className="login-legal">{loginMode === "student" ? "By continuing, you agree to use this portal only for the Rosmini Secondary School election in Tanga, Tanzania." : "Access is restricted to the school administrator account. Every console action is verified by the server."}</p>
            <div className="login-status"><span className="status-dot" /> Election room secure <span className="status-divider" /> <Icon name="shield" size={13} /> Encrypted session</div>
          </div>
          <p className="login-credit">Rosmini Secondary School <span>·</span> Tanga, Tanzania</p>
        </section>
        {welcomeOpen && <WelcomeModal close={dismissWelcome} />}
      </main>
    );
  }

  const isAdmin = session.role === "admin";
  const currentTitle = isAdmin
    ? tab === "settings" ? "Election settings" : tab === "candidates" ? "Candidate registry" : tab === "results" ? "Election overview" : "Administration"
    : tab === "results" ? "The live picture" : tab === "guide" ? "How voting works" : "Your ballot";

  return (
    <main className="app-shell">
      <header className="topbar">
        <button className="mobile-menu-button" onClick={() => setMobileMenu((value) => !value)} aria-label="Open navigation"><Icon name="menu" /></button>
        <div className="brand-lockup"><SchoolLogo size={34} /><div className="brand-copy"><strong>ROSMINI</strong><span>SECONDARY SCHOOL · TANGA</span></div></div>
        <nav className={`main-nav ${mobileMenu ? "open" : ""}`}>
          <button className={tab === "ballot" ? "active" : ""} onClick={() => { setTab("ballot"); setMobileMenu(false); }}>{isAdmin ? "Overview" : "Ballot"}</button>
          <button className={tab === "results" ? "active" : ""} onClick={() => { setTab("results"); setMobileMenu(false); }}><Icon name="chart" size={15} /> Results</button>
          {isAdmin ? (
            <button className={tab === "candidates" ? "active" : ""} onClick={() => { setTab("candidates"); setMobileMenu(false); }}><Icon name="users" size={15} /> Candidates</button>
          ) : (
            <button className={tab === "guide" ? "active" : ""} onClick={() => { setTab("guide"); setMobileMenu(false); }}>How it works</button>
          )}
          {isAdmin && <button className={tab === "settings" ? "active" : ""} onClick={() => { setTab("settings"); setMobileMenu(false); }}><Icon name="settings" size={15} /> Settings</button>}
        </nav>
        <div className="topbar-account"><div className={`account-avatar ${isAdmin ? "admin-avatar" : ""}`}>{isAdmin ? "A" : session.identity.slice(-2)}</div><div className="account-copy"><strong>{isAdmin ? "Administrator" : `Student ${session.identity}`}</strong><span>{isAdmin ? "Full access" : "Voter access"}</span></div><button className="logout-button" onClick={logOut} aria-label="Sign out"><Icon name="logout" size={17} /></button></div>
      </header>
      <div className="app-body">
        <div className="page-heading"><div><p className="eyebrow">{isAdmin ? "Administration console" : "Student leadership election"}</p><h1>{currentTitle}</h1></div><div className={`status-pill ${status}`.trim()}><span className="status-dot" />{status === "active" ? "Voting is open" : status === "upcoming" ? "Voting opens soon" : status === "closed" ? "Voting is closed" : "Election room"}</div></div>
        {!data ? <DataLoading /> : <>
          {tab === "ballot" && !isAdmin && <StudentBallot data={data} status={status} remaining={remaining} selections={selections} submittedPositions={submittedPositions} selectedCount={selectedCount} chooseCandidate={chooseCandidate} openManifesto={setManifesto} openReview={() => setReviewOpen(true)} />}
          {tab === "guide" && !isAdmin && <Guide />}
          {tab === "results" && <Results data={data} isAdmin={isAdmin} />}
          {tab === "candidates" && isAdmin && <CandidateManager data={data} token={session.token} notify={notify} refresh={() => fetchElection()} />}
          {tab === "ballot" && isAdmin && <AdminOverview data={data} status={status} totalVotes={totalVotes} goToSettings={() => setTab("settings")} goToResults={() => setTab("results")} goToCandidates={() => setTab("candidates")} />}
          {tab === "settings" && isAdmin && <AdminSettings data={data} schedule={schedule} setSchedule={setSchedule} saveSchedule={saveSchedule} savingSchedule={savingSchedule} closeElection={closeElection} sendingNotice={sendingNotice} />}
        </>}
      </div>
      {manifesto && <ManifestoModal candidate={manifesto} close={() => setManifesto(null)} />}
      {reviewOpen && <ReviewModal data={data} selections={selections} submittedPositions={submittedPositions} close={() => setReviewOpen(false)} submit={submitBallot} />}
      {welcomeOpen && <WelcomeModal close={dismissWelcome} />}
      {toast && <div className={`toast ${toast.type}`}><span className="toast-icon"><Icon name={toast.type === "success" ? "check" : toast.type === "error" ? "info" : "clock"} size={16} /></span>{toast.message}<button onClick={() => setToast(null)} aria-label="Dismiss"><Icon name="close" size={14} /></button></div>}
    </main>
  );
}

function StudentBallot({ data, status, remaining, selections, submittedPositions, selectedCount, chooseCandidate, openManifesto, openReview }: {
  data: ElectionData;
  status: string;
  remaining: number;
  selections: Record<string, number>;
  submittedPositions: string[];
  selectedCount: number;
  chooseCandidate: (position: string, candidateId: number) => void;
  openManifesto: (candidate: Candidate) => void;
  openReview: () => void;
}) {
  const hasCandidates = data.candidates.length > 0;
  return <>
    <section className="countdown-banner"><div className="countdown-intro"><div className="countdown-icon"><Icon name="clock" size={22} /></div><div><span>{status === "active" ? "Time remaining to vote" : status === "upcoming" ? "Voting opens at" : "Voting session ended"}</span><strong>{status === "active" ? formatTimeLeft(remaining) : status === "upcoming" ? prettyDate(data.settings.startAt) : "Final results are being prepared"}</strong></div></div><div className="countdown-meta"><span>Closes {prettyDate(data.settings.endAt)}</span><span className="live-dot" /> Live countdown</div></section>
    <div className="ballot-intro"><div><p className="eyebrow">{data.positions.length > 0 ? `${data.positions.length} position${data.positions.length === 1 ? "" : "s"} · one considered voice` : "One considered voice"}</p><h2>Make your mark.</h2><p>Select one candidate for each position you want to vote for. You can review your full ballot before anything is submitted.</p></div>{data.positions.length > 0 && <div className="ballot-progress"><div className="progress-ring"><strong>{submittedPositions.length + selectedCount}</strong><span>of {data.positions.length}</span></div><div><strong>Ballot progress</strong><span>{submittedPositions.length ? `${submittedPositions.length} position${submittedPositions.length === 1 ? "" : "s"} already recorded` : "Nothing submitted yet"}</span></div></div>}</div>
    {status !== "active" && <div className={`notice-banner ${status}`}><Icon name={status === "closed" ? "lock" : "clock"} size={17} /><div><strong>{status === "closed" ? "Voting is officially closed." : "Voting has not opened yet."}</strong><span>{status === "closed" ? "Your choices can no longer be changed. Visit Results to see the election picture." : `Come back at ${prettyDate(data.settings.startAt)} to cast your ballot.`}</span></div></div>}
    {!hasCandidates ? (
      <div className="empty-state">
        <Icon name="users" size={26} />
        <h3>The ballot is being prepared.</h3>
        <p>The administration is finalizing the candidate list. Your ballot will appear here as soon as the real candidates are registered.</p>
      </div>
    ) : (
      <>
        <div className="positions-list">
          {data.positions.map((position, index) => {
            const positionCandidates = data.candidates.filter((candidate) => candidate.position === position);
            const selected = selections[position];
            const submitted = submittedPositions.includes(position);
            return <section className={`position-block ${submitted ? "submitted" : ""}`} key={position}>
              <div className="position-heading"><div className="position-number">0{index + 1}</div><div><h3>{position}</h3><p>{submitted ? "Your choice is securely recorded" : "Choose one candidate"}</p></div><div className={`position-state ${submitted ? "done" : selected ? "chosen" : ""}`}>{submitted ? <><Icon name="check" size={14} /> Recorded</> : selected ? <><Icon name="check" size={14} /> Selected</> : "Open"}</div></div>
              <div className="candidate-grid">
                {positionCandidates.map((candidate) => <CandidateCard candidate={candidate} selected={selected === candidate.id} disabled={status !== "active" || submitted} openManifesto={openManifesto} choose={() => chooseCandidate(position, candidate.id)} key={candidate.id} />)}
              </div>
            </section>;
          })}
        </div>
        <div className="ballot-submit-bar"><div><Icon name="shield" size={18} /><span><strong>Your vote is private.</strong> Review every selection before submitting.</span></div><button className="primary-button" disabled={status !== "active" || selectedCount === 0} onClick={openReview}>Review my ballot <Icon name="arrow" size={17} /></button></div>
      </>
    )}
  </>;
}

function CandidateCard({ candidate, selected, disabled, openManifesto, choose }: { candidate: Candidate; selected: boolean; disabled: boolean; openManifesto: (candidate: Candidate) => void; choose: () => void }) {
  return <article className={`candidate-card ${selected ? "selected" : ""} ${disabled ? "disabled" : ""}`} onClick={choose} style={{ "--candidate-accent": candidate.accent } as React.CSSProperties}>
    <div className="candidate-topline"><span className="candidate-label">Candidate</span>{selected && <span className="selected-check"><Icon name="check" size={13} /> Your choice</span>}</div>
    <div className="candidate-profile"><div className="candidate-photo" style={{ background: `linear-gradient(145deg, ${candidate.accent}, #15243e)` }}>{candidate.imageUrl ? <img src={candidate.imageUrl} alt="" /> : <span>{candidate.initials}</span>}</div><div><h4>{candidate.name}</h4><p>{candidate.className}</p></div><span className={`radio ${selected ? "checked" : ""}`} aria-hidden="true"><span /></span></div>
    <p className="candidate-tagline">“{candidate.tagline}”</p>
    <button className="manifesto-link" onClick={(event) => { event.stopPropagation(); openManifesto(candidate); }}>Read their manifesto <Icon name="arrow" size={14} /></button>
  </article>;
}

function ReviewModal({ data, selections, submittedPositions, close, submit }: { data: ElectionData | null; selections: Record<string, number>; submittedPositions: string[]; close: () => void; submit: () => void }) {
  if (!data) return null;
  return <div className="modal-backdrop"><section className="review-modal" role="dialog" aria-modal="true" aria-labelledby="review-title"><div className="modal-top"><div className="modal-icon"><Icon name="shield" size={21} /></div><button className="icon-button" onClick={close} aria-label="Close review"><Icon name="close" /></button></div><p className="eyebrow">One last thoughtful look</p><h2 id="review-title">Review your ballot.</h2><p className="modal-description">Make sure each choice reflects your voice. Once submitted, a choice for a position cannot be changed.</p><div className="review-list">{data.positions.map((position, index) => { const candidate = data.candidates.find((item) => item.id === selections[position]); const recorded = submittedPositions.includes(position); return <div className="review-row" key={position}><span className="review-index">0{index + 1}</span><div><strong>{position}</strong><span>{recorded ? "Already recorded" : candidate ? candidate.name : "No selection — skip this position"}</span></div><span className={recorded ? "review-locked" : candidate ? "review-selected" : "review-skipped"}>{recorded ? <Icon name="lock" size={13} /> : candidate ? <Icon name="check" size={14} /> : "—"}</span></div>; })}</div><div className="review-actions"><button className="secondary-button" onClick={close}>Back to editing</button><button className="primary-button" onClick={submit}>Confirm & submit <Icon name="arrow" size={17} /></button></div><p className="review-footnote"><Icon name="lock" size={13} /> Your ballot is encrypted and linked only to your student number.</p></section></div>;
}

function ManifestoModal({ candidate, close }: { candidate: Candidate; close: () => void }) {
  return <div className="modal-backdrop" onClick={close}><section className="manifesto-modal" onClick={(event) => event.stopPropagation()}><div className="manifesto-cover" style={{ background: `linear-gradient(135deg, ${candidate.accent}, #15243e)` }}><span>{candidate.initials}</span><button className="cover-close" onClick={close} aria-label="Close manifesto"><Icon name="close" /></button></div><div className="manifesto-content"><p className="eyebrow">{candidate.position} · {candidate.className}</p><h2>{candidate.name}</h2><p className="manifesto-quote">“{candidate.tagline}”</p><div className="manifesto-rule" /><h4>My promise to Rosmini</h4><p>{candidate.manifesto}</p><button className="secondary-button" onClick={close}>Return to ballot</button></div></section></div>;
}

function Results({ data, isAdmin }: { data: ElectionData; isAdmin: boolean }) {
  const totalRecorded = Object.values(data.totals).reduce((sum, value) => sum + value, 0);
  return <section className="results-page"><div className="results-hero"><div><p className="eyebrow">{isAdmin ? "Live election intelligence" : "A transparent process"}</p><h2>{isAdmin ? "Every voice, clearly counted." : "The live picture."}</h2><p>{isAdmin ? "Monitor participation and candidate momentum as the school makes its choice." : "Results update as votes are securely recorded. Final outcomes are confirmed after the official close."}</p></div><div className="total-votes"><strong>{totalRecorded}</strong><span>votes recorded</span></div></div>{data.candidates.length === 0 ? (
    <div className="empty-state" style={{ marginTop: 17 }}>
      <Icon name="chart" size={26} />
      <h3>No candidates registered yet.</h3>
      <p>Live results will appear here as soon as the administration registers the candidates and students begin voting.</p>
    </div>
  ) : (
    <>
      <div className="results-metrics"><div className="metric-card"><span className="metric-icon blue"><Icon name="users" /></span><strong>{new Set(data.candidates.map((candidate) => candidate.position)).size}</strong><span>positions on the ballot</span></div><div className="metric-card"><span className="metric-icon gold"><Icon name="chart" /></span><strong>{data.candidates.length}</strong><span>candidate profiles</span></div><div className="metric-card"><span className="metric-icon green"><Icon name="shield" /></span><strong>100%</strong><span>ballot integrity</span></div></div>
      <div className="results-grid">{data.positions.map((position) => { const rows = data.candidates.filter((candidate) => candidate.position === position); const max = Math.max(...rows.map((candidate) => data.totals[candidate.id] ?? 0), 1); const positionTotal = rows.reduce((sum, candidate) => sum + (data.totals[candidate.id] ?? 0), 0); return <section className="result-card" key={position}><div className="result-card-heading"><div><span className="result-kicker">Position</span><h3>{position}</h3></div><span>{positionTotal} total</span></div>{rows.map((candidate, index) => { const count = data.totals[candidate.id] ?? 0; const percentage = positionTotal ? Math.round((count / positionTotal) * 100) : 0; return <div className="bar-row" key={candidate.id}><div className="bar-label"><span className="mini-avatar" style={{ background: candidate.accent }}>{candidate.initials.slice(0, 1)}</span><strong>{candidate.name}</strong>{index === 0 && count > 0 && <span className="leader-tag">Leading</span>}<span className="bar-number">{count} <small>({percentage}%)</small></span></div><div className="bar-track"><span style={{ width: `${Math.max(count ? (count / max) * 100 : 3, 3)}%`, background: candidate.accent }} /></div></div>; })}<div className="result-donut-line"><span className="donut" style={{ background: `conic-gradient(${rows[0]?.accent ?? "#1b3f94"} ${positionTotal ? ((data.totals[rows[0]?.id] ?? 0) / positionTotal) * 360 : 0}deg, #edf1f6 0)` }} /><span>Live tally · {statusFor(data.settings) === "closed" ? "Final" : "Provisional"}</span></div></section>; })}</div>
    </>
  )}</section>;
}

function CandidateManager({ data, token, notify, refresh }: { data: ElectionData; token: string | undefined; notify: Notify; refresh: () => Promise<void> }) {
  const [form, setForm] = useState({ position: "", name: "", className: "", tagline: "", manifesto: "" });
  const [accent, setAccent] = useState("#1b3f94");
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<number | null>(null);

  async function addCandidate(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true);
    try {
      const response = await fetch("/api/candidates", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token, accent, ...form }) });
      const body = await response.json() as { error?: string };
      if (!response.ok) throw new Error(body.error ?? "The candidate could not be added.");
      notify("success", `${form.name.trim()} is now registered for ${form.position.trim()}.`);
      setForm({ position: "", name: "", className: "", tagline: "", manifesto: "" });
      await refresh();
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "The candidate could not be added.");
    } finally {
      setSaving(false);
    }
  }

  async function removeCandidate(id: number) {
    try {
      const response = await fetch("/api/candidates", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token, id }) });
      const body = await response.json() as { error?: string };
      if (!response.ok) throw new Error(body.error ?? "The candidate could not be removed.");
      notify("success", "Candidate removed from the official ballot.");
      setConfirmDelete(null);
      await refresh();
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "The candidate could not be removed.");
    }
  }

  const grouped = data.positions.map((position) => ({ position, list: data.candidates.filter((candidate) => candidate.position === position) }));

  return (
    <section className="candidates-page">
      <div className="candidates-grid">
        <form className="settings-card" onSubmit={addCandidate}>
          <div className="card-heading"><div className="setting-icon"><Icon name="users" /></div><div><h3>Register a candidate</h3><p>Add a confirmed candidate to the official ballot.</p></div></div>
          <div className="form-grid">
            <label><span>Position</span><input list="position-options" value={form.position} onChange={(event) => setForm({ ...form, position: event.target.value })} placeholder="Head Boy" required /></label>
            <label><span>Full name</span><input value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} placeholder="e.g. Grace Mwakalinga" required /></label>
            <label><span>Class</span><input value={form.className} onChange={(event) => setForm({ ...form, className: event.target.value })} placeholder="Form Six · 6A" required /></label>
            <label><span>Campaign line</span><input value={form.tagline} onChange={(event) => setForm({ ...form, tagline: event.target.value })} placeholder="A short motto" /></label>
          </div>
          <datalist id="position-options">{data.positions.map((position) => <option key={position} value={position} />)}</datalist>
          <label className="full-field"><span>Manifesto</span><textarea rows={4} value={form.manifesto} onChange={(event) => setForm({ ...form, manifesto: event.target.value })} placeholder="What will this candidate do for Rosmini?" /></label>
          <div className="accent-row"><span className="field-label">Ballot color</span>{ACCENTS.map((color) => <button type="button" key={color} className={`swatch ${accent === color ? "selected" : ""}`} style={{ background: color }} onClick={() => setAccent(color)} aria-label={`Select ballot color ${color}`} />)}</div>
          <button className="primary-button" type="submit" disabled={saving}>{saving ? "Registering…" : "Register candidate"} <Icon name="arrow" size={16} /></button>
        </form>
        <div className="settings-card">
          <div className="card-heading"><div className="setting-icon gold"><Icon name="shield" /></div><div><h3>Registered candidates</h3><p>{data.candidates.length === 0 ? "The ballot is currently empty." : `${data.candidates.length} candidate${data.candidates.length === 1 ? "" : "s"} on the official ballot.`}</p></div></div>
          {data.candidates.length === 0 ? (
            <div className="empty-state compact"><Icon name="users" size={22} /><h3>No candidates yet</h3><p>Register the first candidate using the form. It will appear on student ballots immediately.</p></div>
          ) : (
            <div className="candidate-registry">
              {grouped.map(({ position, list }) => (
                <div className="registry-group" key={position}>
                  <span className="registry-position">{position}</span>
                  {list.map((candidate) => (
                    <div className="registry-row" key={candidate.id}>
                      <span className="mini-avatar" style={{ background: candidate.accent }}>{candidate.initials.slice(0, 1)}</span>
                      <div><strong>{candidate.name}</strong><span>{candidate.className}</span></div>
                      {confirmDelete === candidate.id ? (
                        <span className="delete-confirm"><button className="confirm-yes" onClick={() => void removeCandidate(candidate.id)}>Remove</button><button className="confirm-no" onClick={() => setConfirmDelete(null)}>Keep</button></span>
                      ) : (
                        <button className="delete-btn" onClick={() => setConfirmDelete(candidate.id)} aria-label={`Remove ${candidate.name}`}><Icon name="trash" size={15} /></button>
                      )}
                    </div>
                  ))}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

function AdminOverview({ data, status, totalVotes, goToSettings, goToResults, goToCandidates }: { data: ElectionData; status: string; totalVotes: number; goToSettings: () => void; goToResults: () => void; goToCandidates: () => void }) {
  return <section className="admin-page"><div className="admin-welcome"><div><span className="admin-badge"><Icon name="shield" size={14} /> Authorized console</span><h2>Good morning, <em>administrator.</em></h2><p>Here is the pulse of the Rosmini Secondary School Tanga leadership election.</p></div><button className="secondary-button" onClick={goToSettings}><Icon name="settings" size={16} /> Manage schedule</button></div><div className="admin-stats"><div><span className="stat-label">Votes recorded</span><strong>{totalVotes}</strong><span className="stat-foot"><span className="green-dot" /> Live from the ballot</span></div><div><span className="stat-label">Election status</span><strong className="status-word">{status === "active" ? "Open" : status === "upcoming" ? "Pending" : "Closed"}</strong><span className="stat-foot">{status === "active" ? `Closes ${prettyDate(data.settings.endAt)}` : status === "closed" ? "Session has ended" : `Starts ${prettyDate(data.settings.startAt)}`}</span></div><div><span className="stat-label">Candidates</span><strong>{data.candidates.length}</strong><span className="stat-foot">On the official ballot</span></div><div><span className="stat-label">Notification</span><strong className={data.settings.notificationSent ? "notified" : "pending-word"}>{data.settings.notificationSent ? "Sent" : "Pending"}</strong><span className="stat-foot">{data.settings.notificationSent ? `At ${prettyDate(data.settings.notificationSentAt ?? data.settings.endAt)}` : "Automatic on official close"}</span></div></div><div className="admin-lower"><div className="admin-callout"><div className="callout-art"><span>R</span><div className="art-star">✦</div></div><div><p className="eyebrow">A considered choice</p><h3>Lead the room,<br />serve the room.</h3><p>Students are choosing leaders who will carry the Rosmini standard forward in Tanga.</p></div></div><div className="quick-actions"><p className="eyebrow">Quick actions</p><button onClick={goToCandidates}><span><Icon name="users" /> Register candidates</span><Icon name="arrow" size={16} /></button><button onClick={goToResults}><span><Icon name="chart" /> View live results</span><Icon name="arrow" size={16} /></button><button onClick={goToSettings}><span><Icon name="clock" /> Update election window</span><Icon name="arrow" size={16} /></button><button onClick={() => window.open("mailto:" + data.settings.administrationEmail)}><span><Icon name="mail" /> Contact administration</span><Icon name="arrow" size={16} /></button></div></div></section>;
}

function AdminSettings({ data, schedule, setSchedule, saveSchedule, savingSchedule, closeElection, sendingNotice }: { data: ElectionData; schedule: { startAt: string; endAt: string; administrationEmail: string }; setSchedule: (value: { startAt: string; endAt: string; administrationEmail: string }) => void; saveSchedule: (event: React.FormEvent<HTMLFormElement>) => void; savingSchedule: boolean; closeElection: () => void; sendingNotice: boolean }) {
  return <section className="settings-page"><div className="settings-intro"><p className="eyebrow">Control room</p><h2>Set the moment.</h2><p>Students can only vote inside this official window. Once it ends, the final tally is automatically sent to the administration inbox.</p></div><div className="settings-grid"><form className="settings-card" onSubmit={saveSchedule}><div className="card-heading"><div className="setting-icon"><Icon name="clock" /></div><div><h3>Election window</h3><p>The official schedule shown to every voter.</p></div></div><div className="form-grid"><label><span>Opens</span><input type="datetime-local" value={schedule.startAt} onChange={(event) => setSchedule({ ...schedule, startAt: event.target.value })} required /></label><label><span>Closes</span><input type="datetime-local" value={schedule.endAt} onChange={(event) => setSchedule({ ...schedule, endAt: event.target.value })} required /></label></div><button className="primary-button" type="submit" disabled={savingSchedule}>{savingSchedule ? "Saving…" : "Save election window"} <Icon name="arrow" size={16} /></button></form><div className="settings-card notification-card"><div className="card-heading"><div className="setting-icon gold"><Icon name="mail" /></div><div><h3>Administration alert</h3><p>Gmail notification after the official close.</p></div></div><label className="full-field"><span>Administration email</span><input type="email" value={schedule.administrationEmail} onChange={(event) => setSchedule({ ...schedule, administrationEmail: event.target.value })} required /></label><div className="gmail-status"><span className={`status-dot ${data.settings.notificationSent ? "sent" : ""}`} /><div><strong>{data.settings.notificationSent ? "Closure email sent" : "Automatic email is armed"}</strong><span>{data.settings.notificationSent ? `Sent ${prettyDate(data.settings.notificationSentAt ?? data.settings.endAt)}` : "Requires GMAIL_USER and GMAIL_APP_PASSWORD on the server"}</span></div></div><button className="secondary-button full-button" type="button" onClick={closeElection} disabled={sendingNotice || new Date(data.settings.endAt) > new Date()}>{sendingNotice ? "Sending…" : new Date(data.settings.endAt) > new Date() ? "Available after official close" : "Send closure notice now"} <Icon name="arrow" size={16} /></button></div></div><div className="security-note"><Icon name="shield" size={18} /><div><strong>Protected administration area</strong><span>Access is restricted to the school administrator account, and every action is verified by the server with a signed session token. The server also enforces the schedule for every submitted ballot.</span></div></div></section>;
}

function Guide() {
  return <section className="guide-page"><div className="guide-lead"><p className="eyebrow">A calm, considered process</p><h2>Your voice has<br /><em>three steps.</em></h2><p>Take your time. A good election is not about being first — it is about choosing the people you trust to serve.</p></div><div className="guide-steps"><div className="guide-step"><span>01</span><div><h3>Explore</h3><p>Read each candidate’s manifesto and consider their promise for Rosmini.</p></div></div><div className="guide-step"><span>02</span><div><h3>Select</h3><p>Choose one candidate for each position. You may vote across all positions on one screen.</p></div></div><div className="guide-step"><span>03</span><div><h3>Review & confirm</h3><p>Check the review screen carefully, then submit your final choices securely.</p></div></div></div><div className="guide-quote"><Icon name="spark" size={24} /><p>“Leadership is not a position or a title, it is action and example.”</p><span>— Student Leadership Office</span></div><div className="guide-capacity"><span>560</span> wanafunzi wenye hesabu · <span>10–13</span> vifaa kwa siku moja. <em>The system supports 560 student accounts and comfortably handles hundreds of votes per minute across 10+ devices in a single day.</em></div></section>;
}
